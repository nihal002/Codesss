module.exports = {
  dbHost: 'localhost',
  dbName: 'appointment-app',
  dbCollection: 'appointments',
};

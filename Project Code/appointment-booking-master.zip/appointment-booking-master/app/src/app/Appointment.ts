export interface Appointment {
  _id: string;
  appointmentDate: string;
  name: string;
  email: string;
}
